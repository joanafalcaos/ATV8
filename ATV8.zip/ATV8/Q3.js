function potencia(x, k) {
    // Se k for igual a 0, o resultado é 1
    if (k === 0) {
        return 1;
    }
    // Se k for igual a 1, o resultado é x
    if (k === 1) {
        return x;
    }
    // Se k for positivo e par, divide k por 2 e multiplicamos x por x
    if (k > 0 && k % 2 === 0) {
        return potencia(x * x, k / 2);
    }
    // Se k for positivo e ímpar, subtrai 1 de k e multiplicamos x pelo resultado da potência com k - 1
    if (k > 0 && k % 2 !== 0) {
        return x * potencia(x, k - 1);
    }
    // Se k for negativo, calcular a potência usando 1 / x e -k (módulo de k)
    if (k < 0) {
        return 1 / potencia(x, -k);
    }
}

// Teste
console.log(potencia(2, 3)); 
console.log(potencia(5, 0)); 
console.log(potencia(3, -2));
