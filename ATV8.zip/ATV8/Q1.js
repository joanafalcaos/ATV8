function somaAteN(N) {
    // Se N for igual a 1, retornar 1
    if (N === 1) {
        return 1;
    } else {
        // Somar N com a soma de todos os números até N-1
        return N + somaAteN(N - 1);
    }
}

// Exemplo
console.log(somaAteN(5)); // Saída: 15 (1 + 2 + 3 + 4 + 5 = 15)
