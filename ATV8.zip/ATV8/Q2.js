function somaInversoAteN(N) {
    // Se N for igual a 1, retornar 1
    if (N === 1) {
        return 1;
    } else {
        // Some 1/N com a soma dos inversos
        return 1 / N + somaInversoAteN(N - 1);
    }
}
// Exemplo
console.log(somaInversoAteN(5));